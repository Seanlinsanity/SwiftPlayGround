import UIKit

class TrieNode {
    let numOfLetter = 26
    let char: Character
    var children: [TrieNode?]
    var isEndOfWord: Bool

    init(_ char: Character = "0") {
        self.char = char
        self.children = Array(repeating: nil, count: numOfLetter)
        self.isEndOfWord = false
    }
}

class Trie {
    let head: TrieNode

    init() {
        head = TrieNode()
    }

    func insert(_ word: String) {
        let chars = Array(word)
        var current = head
        for char in chars {
            let index = getIndex(char)
            if let node = current.children[index] {
                current = node
            } else {
                let newNode = TrieNode(char)
                current.children[index] = newNode
                current = newNode
            }
        }
        current.isEndOfWord = true
    }

    func search(_ word: String) -> Bool {
        let chars = Array(word)
        var current = head
        for char in chars {
            let index = getIndex(char)
            guard let node = current.children[index] else { return false }
            current = node
        }

        return current.isEndOfWord
    }

    func startsWith(_ prefix: String) -> Bool {
        let chars = Array(prefix)
        var current = head
        for char in chars {
            let index = getIndex(char)
            guard let node = current.children[index] else { return false }
            current = node
        }

        return true
    }

    private func getIndex(_ char: Character) -> Int {
        let aChar: Character = "a"
        return Int(char.asciiValue! - aChar.asciiValue!)
    }
}

let trie = Trie()
trie.insert("apple")
trie.search("apple")
trie.search("app")
trie.startsWith("app")
trie.insert("app")
trie.search("app")
