import UIKit

/*
 In this problem, a tree is an undirected graph that is connected and has no cycles.

 You are given a graph that started as a tree with n nodes labeled from 1 to n, with one additional edge added. The added edge has two different vertices chosen from 1 to n, and was not an edge that already existed. The graph is represented as an array edges of length n where edges[i] = [ai, bi] indicates that there is an edge between nodes ai and bi in the graph.

 Return an edge that can be removed so that the resulting graph is a tree of n nodes. If there are multiple answers, return the answer that occurs last in the input.

  

 Example 1:


 Input: edges = [[1,2],[1,3],[2,3]]
 Output: [2,3]
 Example 2:


 Input: edges = [[1,2],[2,3],[3,4],[1,4],[1,5]]
 Output: [1,4]
  

 Constraints:

 n == edges.length
 3 <= n <= 1000
 edges[i].length == 2
 1 <= ai < bi <= edges.length
 ai != bi
 There are no repeated edges.
 The given graph is connected.
 */

class Solution {
    private var parents = [Int]()
    private var rank = [Int]()

    func findRedundantConnection(_ edges: [[Int]]) -> [Int] {
        // build parent and rank
        for node in 1...edges.count {
            parents.append(node)
        }
        rank = Array(repeating: 1, count: edges.count)

        // find-union
        for edge in edges {
            let result = union(edge[0], edge[1])
            if result == false {
                return edge
            }
        }

        return []
    }

    func findParent(_ node: Int) -> Int {
        var parent = parents[node - 1]
        while parent != parents[parent - 1] {
            parents[node - 1] = parents[parent - 1]
            parent = parents[parent - 1]
        }
        return parent
    }

    func union(_ node1: Int, _ node2: Int) -> Bool {
        let parent1 = findParent(node1)
        let parent2 = findParent(node2)
        if parent1 == parent2 {
            return false
        } else {
            if rank[parent2 - 1] > rank[parent1 - 1] {
                parents[parent1 - 1] = parent2
                rank[parent2 - 1] += rank[parent1 - 1]
            } else {
                parents[parent2 - 1] = parent1
                rank[parent1 - 1] += rank[parent2 - 1]
            }
            return true
        }
    }

}
