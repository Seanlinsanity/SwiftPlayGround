import UIKit

/*
 Given an integer array nums of length n and an integer target, find three integers in nums such that the sum is closest to target.

 Return the sum of the three integers.

 You may assume that each input would have exactly one solution.

  

 Example 1:

 Input: nums = [-1,2,1,-4], target = 1
 Output: 2
 Explanation: The sum that is closest to the target is 2. (-1 + 2 + 1 = 2).
 Example 2:

 Input: nums = [0,0,0], target = 1
 Output: 0
 Explanation: The sum that is closest to the target is 0. (0 + 0 + 0 = 0).
  

 Constraints:

 3 <= nums.length <= 500
 -1000 <= nums[i] <= 1000
 -104 <= target <= 104
 */


class Solution {
    func threeSumClosest(_ nums: [Int], _ target: Int) -> Int {
        let nums = nums.sorted()
        var diff: Int = Int.max
        var result = 0
        for index in 0..<nums.count - 2 {
            // index = 0
            if index != 0 && nums[index] == nums[index - 1] { continue }
            let num = nums[index] // 1
            var left = index + 1
            var right = nums.count - 1
            while left < right {
                let sum = nums[left] + nums[right]
                let newDiff = abs(num + sum - target)
                if newDiff == 0 {
                    return target
                }

                if newDiff < diff {
                    result = num + sum
                    diff = newDiff
                }

                if num + sum > target {
                    right -= 1
                } else {
                    left += 1
                }
            }
        }

        return result
    }
}

Solution().threeSumClosest([-1,2,1,-4], 1)
Solution().threeSumClosest([0,0,0], 1)

