import UIKit

/*
 Given a set of positive numbers, partition the set into two subsets with a minimum difference between their subset sums.

 Example 1:

 Input: {1, 2, 3, 9}
 Output: 3
 Explanation: We can partition the given set into two subsets where the minimum absolute difference
 between the sum of numbers is '3'. Following are the two subsets: {1, 2, 3} & {9}.
 Example 2:

 Input: {1, 2, 7, 1, 5}
 Output: 0
 Explanation: We can partition the given set into two subsets where the minimum absolute difference
 between the sum of numbers is '0'. Following are the two subsets: {1, 2, 5} & {7, 1}.
 Example 3:

 Input: {1, 3, 100, 4}
 Output: 92
 Explanation: We can partition the given set into two subsets where the minimum absolute difference
 between the sum of numbers is '92'. Here are the two subsets: {1, 3, 4} & {100}.
 
 
 
 You are given an array of integers stones where stones[i] is the weight of the ith stone.

 We are playing a game with the stones. On each turn, we choose any two stones and smash them together. Suppose the stones have weights x and y with x <= y. The result of this smash is:

 If x == y, both stones are destroyed, and
 If x != y, the stone of weight x is destroyed, and the stone of weight y has new weight y - x.
 At the end of the game, there is at most one stone left.

 Return the smallest possible weight of the left stone. If there are no stones left, return 0.

  

 Example 1:

 Input: stones = [2,7,4,1,8,1]
 Output: 1
 Explanation:
 We can combine 2 and 4 to get 2, so the array converts to [2,7,1,8,1] then,
 we can combine 7 and 8 to get 1, so the array converts to [2,1,1,1] then,
 we can combine 2 and 1 to get 1, so the array converts to [1,1,1] then,
 we can combine 1 and 1 to get 0, so the array converts to [1], then that's the optimal value.
 Example 2:

 Input: stones = [31,26,33,21,40]
 Output: 5
  

 Constraints:

 1 <= stones.length <= 30
 1 <= stones[i] <= 100
 */

class Solution {
    func lastStoneWeightII(_ nums: [Int]) -> Int {
        // edge case
        if nums.count == 1 { return nums[0] }

        let sum = nums.reduce(0, +) // 23
        let half = sum / 2 // 11
        var dp = Array(repeating: Array(repeating: false, count: half + 1), count: nums.count + 1)
        /*
            11 10 9  8  7  6. 5. 4. 3. 2. 1. 0
        2   f, f, f, f, f, f, f, f, f, f, f, t
        7   f, f, f, f, f, f, f, f, f, f, f, t
        4   f, f, f, f, f, f, f, f, f, f, f, t
        1   f, f, f, f, f, f, f, f, f, f, f, t
        8   f, f, f, f, f, f, f, f, f, f, f, t
        1   f, f, f, f, f, f, f, f, f, f, f, t
       []   f, f, f, f, f, f, f, f, f, f, f, t
            
        */
        for row in 0...nums.count {
            dp[row][half] = true
        }

        for row in stride(from: nums.count - 1, through: 0, by: -1) {
            for column in stride(from: half - 1, through: 0, by: -1) {
                // r = 5, c = 10
                let num = nums[row] // 1
                let targetSum = half - column // 1
                if num > targetSum {
                    dp[row][column] = dp[row + 1][column]
                } else {
                    let diff = targetSum - num // 0
                    dp[row][column] = dp[row + 1][column] || dp[row + 1][half - diff]
                }
            }
        }

        for column in 0...half {
            for row in 0...nums.count {
                if dp[row][column] {
                    let closestSum = half - column
                    return (sum - closestSum) - closestSum
                }
            }
        }

        return 0
    }
}

Solution().lastStoneWeightII([31,26,33,21,40])
Solution().lastStoneWeightII([2,7,4,1,8,1])
Solution().lastStoneWeightII([1, 2, 7, 1, 5])
