import UIKit

/*
 Given an integer array nums, return the length of the longest strictly increasing
 subsequence
 .

  

 Example 1:

 Input: nums = [10,9,2,5,3,7,101,18]
 Output: 4
 Explanation: The longest increasing subsequence is [2,3,7,101], therefore the length is 4.
 Example 2:

 Input: nums = [0,1,0,3,2,3]
 Output: 4
 Example 3:

 Input: nums = [7,7,7,7,7,7,7]
 Output: 1
  

 Constraints:

 1 <= nums.length <= 2500
 -104 <= nums[i] <= 104
 */

class Solution {
    func lengthOfLIS(_ nums: [Int]) -> Int {
        // edge case
        if nums.count <= 1 { return nums.count }

        var dp = Array(repeating: 1, count: nums.count)
        var result = 0
        for index in stride(from: nums.count - 2, through: 0, by: -1) {
            let num = nums[index]
            for rightIndex in index..<nums.count {
                if nums[rightIndex] > num {
                    dp[index] = max(dp[index], 1 + dp[rightIndex])
                }
            }
            result = max(result, dp[index])
        }
        return result
    }
}
