import UIKit

/*
 Given the head of a singly linked list and two integers left and right where left <= right, reverse the nodes of the list from position left to position right, and return the reversed list.

  

 Example 1:


 Input: head = [1,2,3,4,5], left = 2, right = 4
 Output: [1,4,3,2,5]
 Example 2:

 Input: head = [5], left = 1, right = 1
 Output: [5]
  

 Constraints:

 The number of nodes in the list is n.
 1 <= n <= 500
 -500 <= Node.val <= 500
 1 <= left <= right <= n
  

 Follow up: Could you do it in one pass?
 */

class ListNode<T> {
    let val: T
    var next: ListNode?
    init(_ val: T, _ next: ListNode<T>? = nil) {
        self.val = val
        self.next = next
    }
}



class Solution {
    // [3,5],1,2
    func reverseBetween(_ head: ListNode<Int>?, _ left: Int, _ right: Int) -> ListNode<Int>? {
        // edge case
        if left == right { return head }

        var prevLeft: ListNode<Int>?// nil
        var nextRight: ListNode<Int>?// nil
        var leftNode: ListNode<Int>? = head // 3
        var rightNode: ListNode<Int>? = head // 5
        var position = 1 // 1
        var prev: ListNode<Int>?
        var current: ListNode<Int>? = head // 3
        while current != nil && position <= right + 1 {
            if position == left - 1 {
                prevLeft = current
            }

            if position == right + 1 {
                nextRight = current
            }

            if position >= left && position <= right {
                if position == left {
                    leftNode = current
                } else if position == right {
                    rightNode = current
                }

                let next = current?.next // 5 => nil
                current?.next = prev // 5->3
                prev = current // prev=5
                current = next // current=nil
            } else {
                prev = current
                current = current?.next
            }

            position += 1 // 2
        }

        var root = head
        if let prevLeft = prevLeft {
            prevLeft.next = rightNode
        } else {
            root = rightNode // 3
        }

        if let nextRight = nextRight {
            leftNode?.next = nextRight
        } else {
            leftNode?.next = nil
        }

        return root
    }
}
