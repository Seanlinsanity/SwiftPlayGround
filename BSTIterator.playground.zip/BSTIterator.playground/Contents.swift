import UIKit

/*
 Implement the BSTIterator class that represents an iterator over the in-order traversal of a binary search tree (BST):

 BSTIterator(TreeNode root) Initializes an object of the BSTIterator class. The root of the BST is given as part of the constructor. The pointer should be initialized to a non-existent number smaller than any element in the BST.
 boolean hasNext() Returns true if there exists a number in the traversal to the right of the pointer, otherwise returns false.
 int next() Moves the pointer to the right, then returns the number at the pointer.
 Notice that by initializing the pointer to a non-existent smallest number, the first call to next() will return the smallest element in the BST.

 You may assume that next() calls will always be valid. That is, there will be at least a next number in the in-order traversal when next() is called.

  

 Example 1:


 Input
 ["BSTIterator", "next", "next", "hasNext", "next", "hasNext", "next", "hasNext", "next", "hasNext"]
 [[[7, 3, 15, null, null, 9, 20]], [], [], [], [], [], [], [], [], []]
 Output
 [null, 3, 7, true, 9, true, 15, true, 20, false]

 Explanation
 BSTIterator bSTIterator = new BSTIterator([7, 3, 15, null, null, 9, 20]);
 bSTIterator.next();    // return 3
 bSTIterator.next();    // return 7
 bSTIterator.hasNext(); // return True
 bSTIterator.next();    // return 9
 bSTIterator.hasNext(); // return True
 bSTIterator.next();    // return 15
 bSTIterator.hasNext(); // return True
 bSTIterator.next();    // return 20
 bSTIterator.hasNext(); // return False
  

 Constraints:

 The number of nodes in the tree is in the range [1, 105].
 0 <= Node.val <= 106
 At most 105 calls will be made to hasNext, and next.
 */

public class TreeNode {
    public let val: Int
    public var left: TreeNode?
    public var right: TreeNode?

    public init(_ val: Int, _ left: TreeNode? = nil, _ right: TreeNode? = nil) {
        self.val = val
        self.left = left
        self.right = right
    }
}


class BSTIterator {
    var stack = [TreeNode]()

    init(_ root: TreeNode?) {
        iterativeInorder(root)
    }

    private func iterativeInorder(_ node: TreeNode?) {
        guard let node = node else { return }
        var current: TreeNode? = node
        while current != nil {
            guard let currentNode = current else { return }
            stack.append(currentNode)
            current = currentNode.left
        }
    }

    func next() -> Int {
        let lastNode = stack.removeLast()
        var current: TreeNode? = lastNode.right
        while current != nil {
            guard let currentNode = current else { return 0 }
            stack.append(currentNode)
            current = currentNode.left
        }

        return lastNode.val
    }

    func hasNext() -> Bool {
        return stack.count > 0
    }
}

let root = TreeNode(7)
let node3 = TreeNode(3)
let node15 = TreeNode(15)
let node9 = TreeNode(9)
let node20 = TreeNode(20)
node15.left = node9
node15.right = node20
root.left = node3
root.right = node15

let iterator = BSTIterator(root)
iterator.next()
iterator.next()
iterator.hasNext()
iterator.next()
iterator.hasNext()
iterator.next()
iterator.hasNext()
iterator.next()
iterator.hasNext()
