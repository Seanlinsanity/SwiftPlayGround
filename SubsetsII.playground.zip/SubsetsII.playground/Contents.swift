import UIKit

/*
 Given an integer array nums that may contain duplicates, return all possible
 subsets
  (the power set).

 The solution set must not contain duplicate subsets. Return the solution in any order.

  

 Example 1:

 Input: nums = [1,2,2]
 Output: [[],[1],[1,2],[1,2,2],[2],[2,2]]
 Example 2:

 Input: nums = [0]
 Output: [[],[0]]
  

 Constraints:

 1 <= nums.length <= 10
 -10 <= nums[i] <= 10
 */
class Solution {
    var result = [[Int]]()
    func subsetsWithDup(_ nums: [Int]) -> [[Int]] {
        let sortedNums = nums.sorted()
        backTracking(0, sortedNums, [Int]())
        return result
    }

    func backTracking(_ index: Int, _ nums: [Int], _ currentList: [Int]) {
        if index == nums.count {
            result.append(currentList)
            return
        }

        let num = nums[index]
        var newCurrentList = currentList
        newCurrentList.append(num)
        backTracking(index + 1, nums, newCurrentList)

        newCurrentList.removeLast()
        var nextIndex = index + 1
        while nextIndex < nums.count && nums[nextIndex] == nums[index] {
            nextIndex += 1
        }
        backTracking(nextIndex, nums, newCurrentList)
    }
}
