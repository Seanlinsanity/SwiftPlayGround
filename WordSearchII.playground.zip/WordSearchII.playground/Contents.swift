import UIKit
/*
 Given an m x n board of characters and a list of strings words, return all words on the board.

 Each word must be constructed from letters of sequentially adjacent cells, where adjacent cells are horizontally or vertically neighboring. The same letter cell may not be used more than once in a word.

  

 Example 1:


 Input: board = [["o","a","a","n"],["e","t","a","e"],["i","h","k","r"],["i","f","l","v"]], words = ["oath","pea","eat","rain"]
 Output: ["eat","oath"]
 Example 2:


 Input: board = [["a","b"],["c","d"]], words = ["abcb"]
 Output: []
  

 Constraints:

 m == board.length
 n == board[i].length
 1 <= m, n <= 12
 board[i][j] is a lowercase English letter.
 1 <= words.length <= 3 * 104
 1 <= words[i].length <= 10
 words[i] consists of lowercase English letters.
 All the strings of words are unique.
 */

class Solution {
    var visited = [[Bool]]()
    var result = Set<String>()

    func findWords(_ board: [[Character]], _ words: [String]) -> [String] {
        // Build Trie
        let trie = Trie()
            for word in words {
            trie.addWord(word)
        }

        let rows = board.count
        let columns = board[0].count
        visited = Array(repeating: Array(repeating: false, count: columns), count: rows)
        for row in 0..<rows {
            for column in 0..<columns {
                // DFS
                dfs(row, column, rows, columns, board, trie.head, "")
            }
        }

        return Array(result)
    }

    func dfs(_ row: Int, _ column: Int, _ rows: Int, _ columns: Int, _ board: [[Character]], _ node: TrieNode, _ word: String) {
        if row < 0 || row >= rows || column < 0 || column >= columns { return }
        if visited[row][column] { return }

        visited[row][column] = true
        let char = board[row][column]
        var currentWord = word
        currentWord.append(char)
        if let nextNode = node.children[Trie.getCharIndex(char)] {
            if nextNode.isEndOfWord { result.insert(currentWord) }

            dfs(row - 1, column, rows, columns, board, nextNode, currentWord)
            dfs(row + 1, column, rows, columns, board, nextNode, currentWord)
            dfs(row, column - 1, rows, columns, board, nextNode, currentWord)
            dfs(row, column + 1, rows, columns, board, nextNode, currentWord)
        }
        visited[row][column] = false
    }
}

class TrieNode {
    let val: Character
    var children: [TrieNode?]
    var isEndOfWord: Bool

    init(_ val: Character) {
        self.val = val
        self.children = Array(repeating: nil, count: 26)
        self.isEndOfWord = false
    }
}

class Trie {
    let head: TrieNode

    init() {
        head = TrieNode("0")
    }

    func addWord(_ word: String) {
        var current = head
        for char in word {
            let index = Trie.getCharIndex(char)
            if let node = current.children[index] {
                current = node
            } else {
                let node = TrieNode(char)
                current.children[index] = node
                current = node
            }
        }

        current.isEndOfWord = true
    }

    func hasPrefix(word: String) -> Bool {
        var current = head
        for char in word {
            let index = Trie.getCharIndex(char)
            if let node = current.children[index] {
                current = node
            } else {
                return false
            }
        }

        return true
    }

    func searchWord(word: String) -> Bool {
        var current = head
        for char in word {
            let index = Trie.getCharIndex(char)
            if let node = current.children[index] {
                current = node
            } else {
                    return false
            }
        }

        return current.isEndOfWord
    }

    static func getCharIndex(_ char: Character) -> Int {
        let aChar: Character = "a"
        return Int(char.asciiValue! - aChar.asciiValue!)
    }
}


Solution().findWords([["o","a","a","n"],["e","t","a","e"],["i","h","k","r"],["i","f","l","v"]], ["oath","pea","eat","rain"])
