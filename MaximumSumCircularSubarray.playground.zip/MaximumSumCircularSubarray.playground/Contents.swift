import UIKit

/*
 Given a circular integer array nums of length n, return the maximum possible sum of a non-empty subarray of nums.

 A circular array means the end of the array connects to the beginning of the array. Formally, the next element of nums[i] is nums[(i + 1) % n] and the previous element of nums[i] is nums[(i - 1 + n) % n].

 A subarray may only include each element of the fixed buffer nums at most once. Formally, for a subarray nums[i], nums[i + 1], ..., nums[j], there does not exist i <= k1, k2 <= j with k1 % n == k2 % n.

  

 Example 1:

 Input: nums = [1,-2,3,-2]
 Output: 3
 Explanation: Subarray [3] has maximum sum 3.
 Example 2:

 Input: nums = [5,-3,5]
 Output: 10
 Explanation: Subarray [5,5] has maximum sum 5 + 5 = 10.
 Example 3:

 Input: nums = [-3,-2,-3]
 Output: -2
 Explanation: Subarray [-2] has maximum sum -2.
  

 Constraints:

 n == nums.length
 1 <= n <= 3 * 104
 -3 * 104 <= nums[i] <= 3 * 104
 */

func maxSubarraySumCircular(_ nums: [Int]) -> Int {
    var prev1 = Int.min
    var prev2 = Int.max
    var subarrayMax = Int.min
    var subarrayMin = Int.max
    var sum = 0
    for num in nums {
        if prev1 < 0 {
            subarrayMax = max(subarrayMax, num)
            prev1 = num
        } else {
            subarrayMax = max(subarrayMax, num + prev1)
            prev1 = num + prev1
        }

        if prev2 > 0 {
            subarrayMin = min(subarrayMin, num)
            prev2 = num
        } else {
            subarrayMin = min(subarrayMin, num + prev2)
            prev2 = num + prev2
        }

        sum += num
    }

    if subarrayMax < 0 { return subarrayMax }
    return max(subarrayMax, sum - subarrayMin)
}
