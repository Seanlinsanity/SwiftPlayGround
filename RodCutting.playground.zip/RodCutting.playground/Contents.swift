import UIKit

/*
 Given a rod of length 'n', we are asked to cut the rod and sell the pieces in a way that will maximize the profit. We are also given the price of every piece of length 'i' where '1 <= i <= n'.

 Example:

 Lengths: [1, 2, 3, 4, 5]
 Prices: [2, 6, 7, 10, 13]
 Rod Length: 5

 Let's try different combinations of cutting the rod:

 Five pieces of length 1 => 10 price
 Two pieces of length 2 and one piece of length 1 => 14 price
 One piece of length 3 and two pieces of length 1 => 11 price
 One piece of length 3 and one piece of length 2 => 13 price
 One piece of length 4 and one piece of length 1 => 12 price
 One piece of length 5 => 13 price

 This shows that we get the maximum price (14) by cutting the rod into two pieces of length '2' and one piece of length '1'.
 */

class Solution {
    func rodCutting(_ lengths: [Int], _ prices: [Int], _ rodLength: Int) -> Int {
        var dp = Array(repeating: Array(repeating: 0, count: rodLength + 1), count: lengths.count + 1)
        for row in stride(from: lengths.count - 1, through: 0, by: -1) {
            for column in stride(from: rodLength - 1, through: 0, by: -1) {
                let currentLength = lengths[row]
                let currentRodLength = rodLength - column
                let price = prices[row]
                var result = 0
                if currentLength <= currentRodLength {
                    let left = currentRodLength - currentLength
                    result = max(result, price + dp[row][rodLength - left])
                }
                result = max(result, dp[row + 1][column])
                dp[row][column] = result
            }
        }
        return dp[0][0]
    }
    
    var cache = [[Int]]()
    func rodCutting2(_ lengths: [Int], _ prices: [Int], _ rodLength: Int) -> Int {
        cache = Array(repeating: Array(repeating: 0, count: lengths.count), count: rodLength + 1)
        return rodCutting(0, lengths, prices, rodLength)
    }

    func rodCutting(_ index: Int, _ lengths: [Int], _ prices: [Int], _ rodLength: Int) -> Int {
        if index >= lengths.count ||  rodLength == 0 {
            return 0
        }

        if cache[rodLength][index] != 0 {
            return cache[rodLength][index]
        }

        let length = lengths[index]
        let price = prices[index]
        var result = 0
            if rodLength >= length {
            result = max(result, price + rodCutting(index, lengths, prices, rodLength - length))
        }

        result = max(result, rodCutting(index + 1, lengths, prices, rodLength))
        cache[rodLength][index] = result
        return result
    }

}

Solution().rodCutting2([1, 2, 3, 4, 5], [2, 6, 7, 10, 13], 5)
Solution().rodCutting([1, 2, 3, 4, 5], [2, 6, 7, 10, 13], 5)
