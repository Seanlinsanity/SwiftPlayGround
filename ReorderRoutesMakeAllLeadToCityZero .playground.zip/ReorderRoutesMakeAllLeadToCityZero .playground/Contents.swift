import UIKit

var greeting = "Hello, playground"

class Solution {
   struct Node {
        public let val: Int
        public let canReach: Bool
        
        public init(_ val: Int, _ canReach: Bool) {
            self.val = val
            self.canReach = canReach
        }
    }

    func minReorder(_ n: Int, _ connections: [[Int]]) -> Int {
        // build the graph
        var adjGraph = [Int: [Node]]()
        for connection in connections {
            let fromCity = connection[0]
            let toCity = connection[1]
            adjGraph[fromCity] = adjGraph[fromCity, default: []] + [Node(toCity, false)]
            adjGraph[toCity] = adjGraph[toCity, default: []] + [Node(fromCity, true)]
        }

        // bfs
        var count = 0
        var visited = Array(repeating: false, count: n)
        var queue = Queue<Node>()
        queue.add(Node(0, true))
        while queue.size() > 0 {
            let size = queue.size()
            for _ in 0..<size {
                guard let node = queue.remove() else { return 0 }
                if visited[node.val] { continue }

                visited[node.val] = true
                if !node.canReach { count += 1 }
                if let adjList = adjGraph[node.val] {
                    for adjNode in adjList {
                        queue.add(adjNode)
                    }
                }
            }
        }

        return count
    }

}

class ListNode<T> {
    var value: T
    var next: ListNode<T>?

    init(value: T) {
        self.value = value
    }
}

class Queue<T> {
    private var head: ListNode<T>?
    private var tail: ListNode<T>?
    var count: Int = 0

    var isEmpty: Bool {
        return head == nil
    }

    func add(_ value: T) {
        let newNode = ListNode(value: value)

        if isEmpty {
            head = newNode
            tail = newNode
        } else {
            tail?.next = newNode
            tail = newNode
        }
        count += 1
    }

    func remove() -> T? {
        guard let currentHead = head else {
            return nil
        }

        head = currentHead.next

        if isEmpty {
            tail = nil
        }

        count -= 1

        return currentHead.value
    }

    func peek() -> T? {
        return head?.value
    }

    func size() -> Int {
        return count
    }
}

Solution().minReorder(6, [[0,1],[1,3],[2,3],[4,0],[4,5]])
