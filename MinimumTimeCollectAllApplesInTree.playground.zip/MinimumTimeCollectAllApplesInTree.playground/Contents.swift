import UIKit

/*
 Given an undirected tree consisting of n vertices numbered from 0 to n-1, which has some apples in their vertices. You spend 1 second to walk over one edge of the tree. Return the minimum time in seconds you have to spend to collect all apples in the tree, starting at vertex 0 and coming back to this vertex.

 The edges of the undirected tree are given in the array edges, where edges[i] = [ai, bi] means that exists an edge connecting the vertices ai and bi. Additionally, there is a boolean array hasApple, where hasApple[i] = true means that vertex i has an apple; otherwise, it does not have any apple.

  

 Example 1:


 Input: n = 7, edges = [[0,1],[0,2],[1,4],[1,5],[2,3],[2,6]], hasApple = [false,false,true,false,true,true,false]
 Output: 8
 Explanation: The figure above represents the given tree where red vertices have an apple. One optimal path to collect all apples is shown by the green arrows.
 Example 2:


 Input: n = 7, edges = [[0,1],[0,2],[1,4],[1,5],[2,3],[2,6]], hasApple = [false,false,true,false,false,true,false]
 Output: 6
 Explanation: The figure above represents the given tree where red vertices have an apple. One optimal path to collect all apples is shown by the green arrows.
 Example 3:

 Input: n = 7, edges = [[0,1],[0,2],[1,4],[1,5],[2,3],[2,6]], hasApple = [false,false,false,false,false,false,false]
 Output: 0
  

 Constraints:

 1 <= n <= 105
 edges.length == n - 1
 edges[i].length == 2
 0 <= ai < bi <= n - 1
 hasApple.length == n
 */

class Solution {
    var visited = [Bool]()
    func minTime(_ n: Int, _ edges: [[Int]], _ hasApple: [Bool]) -> Int {
        // edge case
        if n == 1 { return 0 }
        // [[0,2],[0,3],[1,2]]
        // build the treeGrap => O (edges.count), O(edges.count)
        var treeGraph = [Int: [Int]]()
        // { 0: [2,3], 1: [2], 2: [0,1], 3: [0] }
        for edge in edges {
            let parent = edge[0] // 2
            let child = edge[1] // 3
            treeGraph[parent] = treeGraph[parent, default: []] + [child]
            treeGraph[child] = treeGraph[child, default: []] + [parent]
        }

        // dfs => O (n), O(n)
        visited = Array(repeating: false, count: n)
        let result = dfs(0, treeGraph, hasApple)
        return result.1
    }

    func dfs(_ startNode: Int, _ treeGraph: [Int: [Int]], _ hasApple: [Bool]) -> (Bool, Int) {
        if visited[startNode] { return (false, 0) }

        visited[startNode] = true

        guard let children = treeGraph[startNode] else { return (false, 0) }
        var count = 0
        var hasAppleToCollect = false
        for child in children {
            var result = dfs(child, treeGraph, hasApple)
            if result.0 {
                count += (result.1 + 2) // 0 + 2 = 2
                hasAppleToCollect = true  // hasAppleToCollect = true
            }
        }

        if hasApple[startNode] {
            hasAppleToCollect = true
        }

        return (hasAppleToCollect, count)
    }
}
