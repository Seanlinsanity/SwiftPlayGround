import UIKit

/*
 You are given the head of a singly linked-list. The list can be represented as:

 L0 → L1 → … → Ln - 1 → Ln
 Reorder the list to be on the following form:

 L0 → Ln → L1 → Ln - 1 → L2 → Ln - 2 → …
 You may not modify the values in the list's nodes. Only nodes themselves may be changed.

  

 Example 1:


 Input: head = [1,2,3,4]
 Output: [1,4,2,3]
 Example 2:


 Input: head = [1,2,3,4,5]
 Output: [1,5,2,4,3]
  

 Constraints:

 The number of nodes in the list is in the range [1, 5 * 104].
 1 <= Node.val <= 1000
 */


public class ListNode {
    public var val: Int
    public var next: ListNode?
    
    public init(_ val: Int, _ next: ListNode? = nil) {
        self.val = val
        self.next = next
    }
}

class Solution {
    func reorderList(_ head: ListNode?) {
        var slow: ListNode? = head
        var fast: ListNode? = head?.next
        while fast != nil && fast?.next != nil {
            slow = slow?.next
            fast = fast?.next?.next
        }

        let second = slow?.next
        var first = head
        var reverseSecond = reverseList(second)
        while reverseSecond != nil {
            let temp1 = first?.next
            let temp2 = reverseSecond?.next

            first?.next = reverseSecond
            reverseSecond?.next = temp1

            first = temp1
            reverseSecond = temp2
        }

        first?.next = nil
    }

    func reverseList(_ head: ListNode?) -> ListNode? {
        guard let head = head else { return nil }

        var prev: ListNode?
        var current: ListNode? = head // 1
        while current != nil {
            // current=5
            let temp = current?.next // nil
            current?.next = prev // 5->4->3->2->1->nil
            prev = current // 5
            current = temp // nil
        }

        return prev
    }

}
