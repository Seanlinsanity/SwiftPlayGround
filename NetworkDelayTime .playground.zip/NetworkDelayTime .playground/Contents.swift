import UIKit

/*
 You are given a network of n nodes, labeled from 1 to n. You are also given times, a list of travel times as directed edges times[i] = (ui, vi, wi), where ui is the source node, vi is the target node, and wi is the time it takes for a signal to travel from source to target.

 We will send a signal from a given node k. Return the minimum time it takes for all the n nodes to receive the signal. If it is impossible for all the n nodes to receive the signal, return -1.

  

 Example 1:


 Input: times = [[2,1,1],[2,3,1],[3,4,1]], n = 4, k = 2
 Output: 2
 Example 2:

 Input: times = [[1,2,1]], n = 2, k = 1
 Output: 1
 Example 3:

 Input: times = [[1,2,1]], n = 2, k = 2
 Output: -1
  

 Constraints:

 1 <= k <= n <= 100
 1 <= times.length <= 6000
 times[i].length == 3
 1 <= ui, vi <= n
 ui != vi
 0 <= wi <= 100
 All the pairs (ui, vi) are unique. (i.e., no multiple edges.)
 */

class Solution {
    public struct Node: Comparable {
        public let val: Int
        public let time: Int
        
        public init(_ val: Int, _ time: Int) {
            self.val = val
            self.time = time
        }

        public static func < (lhs: Node, rhs: Node) -> Bool {
            return lhs.time < rhs.time
        }
    }

    func networkDelayTime(_ times: [[Int]], _ numOfNodes: Int, _ start: Int) -> Int {
        // build graph
        var adjGraph = [Int: [[Int]]]()
        for time in times {
            let source = time[0]
            let target = time[1]
            let timeValue = time[2]
            adjGraph[source] = adjGraph[source, default: []] + [[target, timeValue]]
        }
        
        // find shortest path
        let minHeap = MinHeap<Node>()
        var visited = Set<Int>()
        minHeap.add(Node(start, 0))
        var result = -1
        while minHeap.size() > 0 {
            guard let node = minHeap.poll() else { return -1 }
            
            if visited.contains(node.val) { continue }

            visited.insert(node.val)
            result = max(result, node.time)
            
            if let adj = adjGraph[node.val] {
                for neighbor in adj {
                    minHeap.add(Node(neighbor[0], neighbor[1] + node.time))
                }
            }
        }

        return visited.count == numOfNodes ? result : -1

    }

    public class MinHeap<T: Comparable> {
        private var nodes = [T]()
        
        public func size() -> Int {
            return nodes.count
        }
        
        public func peek() -> T? {
            return nodes.first
        }

        public func leftChildIndex(_ index: Int) -> Int? {
            let leftIndex = index * 2 + 1
            return leftIndex < nodes.count ? leftIndex : nil
        }

        public func rightChildIndex(_ index: Int) -> Int? {
            let rightIndex = index * 2 + 2
            return rightIndex < nodes.count ? rightIndex : nil
        }
        
        public func parent(_ index: Int) -> Int? {
            if index == 0 {
                return nil
            }
            return (index - 1) / 2
        }

        public func add(_ element: T) {
            nodes.append(element)
            heapifyUp()
        }

        public func poll() -> T? {
            if nodes.isEmpty {
                return nil
            }
            
            swap(0, nodes.count - 1)
            let num = nodes.removeLast()
            heapifyDown()
            return num
        }

        private func swap(_ index1: Int, _ index2: Int) {
            let temp = nodes[index1]
            nodes[index1] = nodes[index2]
            nodes[index2] = temp
        }

        private func heapifyUp() {
            var current = nodes.count - 1
            while let parentIndex = parent(current), nodes[current] < nodes[parentIndex] {
                swap(current, parentIndex)
                current = parentIndex
            }
        }

        private func heapifyDown() {
            var current = 0
            while true {
                let left = leftChildIndex(current)
                let right = rightChildIndex(current)
                
                var minIndex = current
                if let left = left, nodes[left] < nodes[minIndex] {
                    minIndex = left
                }

                if let right = right, nodes[right] < nodes[minIndex] {
                    minIndex = right
                }

                if minIndex == current {
                    break
                }
                
                swap(minIndex, current)
                current = minIndex
            }
        }
    }
}
