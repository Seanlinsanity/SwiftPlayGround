import UIKit

/*
 You are given an array of non-overlapping intervals intervals where intervals[i] = [starti, endi] represent the start and the end of the ith interval and intervals is sorted in ascending order by starti. You are also given an interval newInterval = [start, end] that represents the start and end of another interval.

 Insert newInterval into intervals such that intervals is still sorted in ascending order by starti and intervals still does not have any overlapping intervals (merge overlapping intervals if necessary).

 Return intervals after the insertion.

  

 Example 1:

 Input: intervals = [[1,3],[6,9]], newInterval = [2,5]
 Output: [[1,5],[6,9]]
 Example 2:

 Input: intervals = [[1,2],[3,5],[6,7],[8,10],[12,16]], newInterval = [4,8]
 Output: [[1,2],[3,10],[12,16]]
 Explanation: Because the new interval [4,8] overlaps with [3,5],[6,7],[8,10].
  

 Constraints:

 0 <= intervals.length <= 104
 intervals[i].length == 2
 0 <= starti <= endi <= 105
 intervals is sorted by starti in ascending order.
 newInterval.length == 2
 0 <= start <= end <= 105
 */

class Solution {
    func insert(_ intervals: [[Int]], _ newInterval: [Int]) -> [[Int]] {
         if intervals.count == 0 { return [newInterval] }

         var insertedIntervals = [[Int]]()
         var isNewInserted = false
         var index = 0
         while index < intervals.count {
             let interval = intervals[index]
             var current = [0,0]
             if isNewInserted {
                 current = interval
                 index += 1
             } else {
                 isNewInserted = newInterval[0] < interval[0]
                 current = isNewInserted ? newInterval : interval
                 if !isNewInserted { index += 1 }
             }

             if insertedIntervals.count == 0 {
                 insertedIntervals.append(current)
             } else {
                 let prev = insertedIntervals[insertedIntervals.count - 1]
                 if prev[1] >= current[0] {
                     insertedIntervals[insertedIntervals.count - 1][1] = max(prev[1], current[1])
                 } else {
                     insertedIntervals.append(current)
                 }
             }
         }

         if !isNewInserted {
             let prev = insertedIntervals[insertedIntervals.count - 1]
             if prev[1] >= newInterval[0] {
                 insertedIntervals[insertedIntervals.count - 1][1] = max(prev[1], newInterval[1])
             } else {
                 insertedIntervals.append(newInterval)
             }
         }
         return insertedIntervals
    }
    
    func insert2(_ intervals: [[Int]], _ newInterval: [Int]) -> [[Int]] {
        var res: [[Int]] = []
        var i = 0
        let n = intervals.count
        
        var currInterval = newInterval
        
        while i < n && intervals[i][1] < newInterval[0] {
            res.append(intervals[i])
            i += 1
        }
        
        while i < n && intervals[i][0] <= currInterval[1] {
            currInterval[0] = min(currInterval[0], intervals[i][0])
            currInterval[1] = max(currInterval[1], intervals[i][1])
            i += 1
        }
        res.append(currInterval)
        
        while i < n {
            res.append(intervals[i])
            i += 1
        }
        return res
    }
}
