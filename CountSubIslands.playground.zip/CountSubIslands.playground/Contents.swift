import UIKit

/*
 You are given two m x n binary matrices grid1 and grid2 containing only 0's (representing water) and 1's (representing land). An island is a group of 1's connected 4-directionally (horizontal or vertical). Any cells outside of the grid are considered water cells.

 An island in grid2 is considered a sub-island if there is an island in grid1 that contains all the cells that make up this island in grid2.

 Return the number of islands in grid2 that are considered sub-islands.

  

 Example 1:


 Input: grid1 = [[1,1,1,0,0],[0,1,1,1,1],[0,0,0,0,0],[1,0,0,0,0],[1,1,0,1,1]], grid2 = [[1,1,1,0,0],[0,0,1,1,1],[0,1,0,0,0],[1,0,1,1,0],[0,1,0,1,0]]
 Output: 3
 Explanation: In the picture above, the grid on the left is grid1 and the grid on the right is grid2.
 The 1s colored red in grid2 are those considered to be part of a sub-island. There are three sub-islands.
 Example 2:


 Input: grid1 = [[1,0,1,0,1],[1,1,1,1,1],[0,0,0,0,0],[1,1,1,1,1],[1,0,1,0,1]], grid2 = [[0,0,0,0,0],[1,1,1,1,1],[0,1,0,1,0],[0,1,0,1,0],[1,0,0,0,1]]
 Output: 2
 Explanation: In the picture above, the grid on the left is grid1 and the grid on the right is grid2.
 The 1s colored red in grid2 are those considered to be part of a sub-island. There are two sub-islands.
  

 Constraints:

 m == grid1.length == grid2.length
 n == grid1[i].length == grid2[i].length
 1 <= m, n <= 500
 grid1[i][j] and grid2[i][j] are either 0 or 1.
 */


class Solution {
    var visited = [[Bool]]()

    func countSubIslands(_ grid1: [[Int]], _ grid2: [[Int]]) -> Int {
        let rows = grid1.count
        let columns = grid1[0].count

        visited = Array(repeating: Array(repeating: false, count: columns), count: rows)
        var count = 0
        for row in 0..<rows {
            for column in 0..<columns {
                if !visited[row][column] && grid1[row][column] == 1 && grid2[row][column] == 1 {
                    if subIslandDfs(row, column, rows, columns, grid1, grid2) {
                        count += 1
                    }
                }
            }
        }

        return count
    }

    func subIslandDfs(_ row: Int, _  column: Int, _ rows: Int, _ columns: Int,  _ grid1: [[Int]], _ grid2: [[Int]]) -> Bool {
        if row < 0 || row >= rows || column < 0 || column >= columns { return true }
        if visited[row][column] || grid2[row][column] == 0 { return true }

        visited[row][column] = true

        let nextList = [
            [row - 1, column],
            [row + 1, column],
            [row, column - 1],
            [row, column + 1]
        ]
            
        var isSubland = true
        for position in nextList where !subIslandDfs(position[0], position[1], rows, columns, grid1, grid2) {
            isSubland = false
        }

        if grid1[row][column] != 1 { return false }
        return isSubland
    }
}
