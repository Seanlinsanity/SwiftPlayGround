import UIKit

/*
 
 Given the root of a binary tree, return the zigzag level order traversal of its nodes' values. (i.e., from left to right, then right to left for the next level and alternate between).

  

 Example 1:


 Input: root = [3,9,20,null,null,15,7]
 Output: [[3],[20,9],[15,7]]
 Example 2:

 Input: root = [1]
 Output: [[1]]
 Example 3:

 Input: root = []
 Output: []
  

 Constraints:

 The number of nodes in the tree is in the range [0, 2000].
 -100 <= Node.val <= 100
 
 */

public class TreeNode {
    public let val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init(_ val: Int, _ left: TreeNode? = nil, _ right: TreeNode? = nil) {
        self.val = val
        self.left = left
        self.right = right
    }
}



class Solution {
    func zigzagLevelOrder(_ root: TreeNode?) -> [[Int]] {
        guard let root = root else { return [] }
    
        var result = [[Int]]()
        let queue = Queue<TreeNode>()
        queue.add(root) // q = [3]
        var isFromLeft = true // false
        while queue.size() > 0 { // q = [20]
            let size = queue.size() // size = 2
            var nodeList = Array(repeating: 0, count: size) // [0, 0]
            for index in 0..<size {
                guard let node = queue.remove() else { return [] } // 20
                if let left = node.left {
                    queue.add(left) // q = [15,7]
                }

                if let right = node.right {
                    queue.add(right)
                }

                let nodeIndex = isFromLeft ? index : (size - 1) - index // 0
                nodeList[nodeIndex] = node.val // [20,9]
            }

            result.append(nodeList) // [[3]]
            isFromLeft = !isFromLeft // false
        }

        return result
    }
}

class Node<T> {
    var value: T
    var next: Node<T>?

    init(value: T) {
        self.value = value
    }
}

class Queue<T> {
    private var head: Node<T>?
    private var tail: Node<T>?
        private var count = 0

    var isEmpty: Bool {
        return head == nil
    }

    func add(_ value: T) {
        let newNode = Node(value: value)

        if isEmpty {
            head = newNode
            tail = newNode
        } else {
            tail?.next = newNode
            tail = newNode
        }
        count += 1
    }

    func remove() -> T? {
        guard let currentHead = head else {
            return nil
        }

        head = currentHead.next

        if isEmpty {
            tail = nil
        }

        count -= 1

        return currentHead.value
    }

    func peek() -> T? {
        return head?.value
    }

    func size() -> Int {
        return count
    }
}
