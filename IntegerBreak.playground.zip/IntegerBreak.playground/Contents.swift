import UIKit

/*
 Given an integer n, break it into the sum of k positive integers, where k >= 2, and maximize the product of those integers.

 Return the maximum product you can get.

  

 Example 1:

 Input: n = 2
 Output: 1
 Explanation: 2 = 1 + 1, 1 × 1 = 1.
 Example 2:

 Input: n = 10
 Output: 36
 Explanation: 10 = 3 + 3 + 4, 3 × 3 × 4 = 36.
  

 Constraints:

 2 <= n <= 58
 */

class Solution {
    func integerBreak(_ n: Int) -> Int {
        var dp = Array(repeating: 0, count: n + 1)
        dp[1] = 1   // dp = [0,1,0,0,0,0,0,0,0,0,0]

        for target in 2...n {
            var result = 1
            for num in 1..<target {
                let left = target - num
                result = max(result, max(num * left, num * dp[left]))
            }
            dp[target] = result
        }
        return dp[n]
    }
    
    var cache = [Int]()
    // cache = [0,1,0,0,0,0,0,0,0,0,0]
    func integerBreak2(_ n: Int) -> Int {
        cache = Array(repeating: 0, count: n + 1)
        cache[1] = 1
        return integerBreakRecursion(n)
    }
    
    func integerBreakRecursion(_ n: Int) -> Int {
        if cache[n] > 0 {
            return cache[n]
        }

        var result = 1
        for num in 1..<n {
            let left = n - num
            result = max(result, max(num * left, num * integerBreakRecursion(left)))
        }
        cache[n] = result
        return result
    }
}

Solution().integerBreak(2)
Solution().integerBreak2(2)

Solution().integerBreak(10)
Solution().integerBreak2(10)
