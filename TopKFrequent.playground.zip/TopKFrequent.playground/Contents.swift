import UIKit

/*
 Given an integer array nums and an integer k, return the k most frequent elements. You may return the answer in any order.

  

 Example 1:

 Input: nums = [1,1,1,2,2,3], k = 2
 Output: [1,2]
 Example 2:

 Input: nums = [1], k = 1
 Output: [1]
  

 Constraints:

 1 <= nums.length <= 105
 -104 <= nums[i] <= 104
 k is in the range [1, the number of unique elements in the array].
 It is guaranteed that the answer is unique.
  

 Follow up: Your algorithm's time complexity must be better than O(n log n), where n is the array's size.
 */

class Solution {
    func topKFrequent(_ nums: [Int], _ topK: Int) -> [Int] {
        // edge case
        if nums.count == 1 { return nums }

        var dict = [Int: Int]()
        for num in nums {
            if let count = dict[num] {
                dict[num] = count + 1
            } else {
                dict[num] = 1
            }
        }

        let minHeap = MinHeap<Node>()
        for (num, count) in dict {
            if minHeap.size() < topK {
                minHeap.add(Node(num, count))
            } else {
                if let root = minHeap.peek(), count > root.count {
                    _ = minHeap.poll()
                    minHeap.add(Node(num, count))
                }
            }
        }

        return minHeap.getNodes().map { $0.val }
    }
}

public struct Node: Comparable {
    public let val: Int
    public let count: Int

    init(_ val: Int, _ count: Int) {
            self.val = val
            self.count = count
    }

    public static func < (lhs: Node, rhs: Node) -> Bool {
        return lhs.count < rhs.count
    }
}

public class MinHeap<T: Comparable> {
    private var nodes = [T]()

    public func size() -> Int {
        return nodes.count
    }

    public func getNodes() -> [T] {
        return nodes
    }

    public func peek() -> T? {
        return nodes.first
    }

    public func leftChildIndex(_ index: Int) -> Int? {
        let leftIndex = index * 2 + 1
        return leftIndex < nodes.count ? leftIndex : nil
    }

    public func rightChildIndex(_ index: Int) -> Int? {
        let rightIndex = index * 2 + 2
        return rightIndex < nodes.count ? rightIndex : nil
    }

    public func parent(_ index: Int) -> Int? {
        if index == 0 {
            return nil
        }
        return (index - 1) / 2
    }

    public func add(_ element: T) {
        nodes.append(element)
        heapifyUp()
    }

    public func poll() -> T? {
        if nodes.isEmpty {
            return nil
        }

        swap(0, nodes.count - 1)
        let num = nodes.removeLast()
        heapifyDown()
        return num
    }

    private func swap(_ index1: Int, _ index2: Int) {
        let temp = nodes[index1]
        nodes[index1] = nodes[index2]
        nodes[index2] = temp
    }

    private func heapifyUp() {
        var current = nodes.count - 1
        while let parentIndex = parent(current), nodes[current] < nodes[parentIndex] {
            swap(current, parentIndex)
            current = parentIndex
        }
    }

    private func heapifyDown() {
        var current = 0
        while true {
            let left = leftChildIndex(current)
            let right = rightChildIndex(current)

            var minIndex = current
            if let left = left, nodes[left] < nodes[minIndex] {
                minIndex = left
            }

            if let right = right, nodes[right] < nodes[minIndex] {
                minIndex = right
            }

            if minIndex == current {
                break
            }

            swap(minIndex, current)
            current = minIndex
        }
    }
}
