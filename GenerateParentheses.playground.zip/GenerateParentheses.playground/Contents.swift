import UIKit

/*
 Given n pairs of parentheses, write a function to generate all combinations of well-formed parentheses.

  

 Example 1:

 Input: n = 3
 Output: ["((()))","(()())","(())()","()(())","()()()"]
 Example 2:

 Input: n = 1
 Output: ["()"]
  

 Constraints:

 1 <= n <= 8
 */

class Solution {
    var result = [String]()
    func generateParenthesis(_ n: Int) -> [String] {
        generateParentheses(0, 0, n, [])
        return result
    }

    func generateParentheses(_ openCount: Int, _ pairs: Int, _ n: Int, _ chars: [Character]) {
        if openCount == 0 {
            return generateParentheses(1, pairs, n, ["("])
        }

        if openCount == n && pairs == n {
            result.append(String(chars))
            return
        }

        if openCount < n {
            generateParentheses(openCount + 1, pairs, n, chars + ["("])
        }

        if pairs < openCount {
            generateParentheses(openCount, pairs + 1, n, chars + [")"])
        }
    }
}

Solution().generateParenthesis(3)
