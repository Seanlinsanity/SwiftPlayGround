import UIKit

/*
 Given an integer n, return the least number of perfect square numbers that sum to n.

 A perfect square is an integer that is the square of an integer; in other words, it is the product of some integer with itself. For example, 1, 4, 9, and 16 are perfect squares while 3 and 11 are not.

  

 Example 1:

 Input: n = 12
 Output: 3
 Explanation: 12 = 4 + 4 + 4.
 Example 2:

 Input: n = 13
 Output: 2
 Explanation: 13 = 4 + 9.
  

 Constraints:

 1 <= n <= 104
 
 */

class Solution {
    func numSquares(_ n: Int) -> Int {
        // edge case
        if n == 1 { return 1 }

        var perfectSquares = [Int]()
        // O(square root of n)
        for num in 1..<n {
            let square = num * num
            if square <= n {
                perfectSquares.append(square)
            } else {
                break
            }
        }

        // perfectSquares=[1,4,9]
        // [0,1,2,3,1,2,3,4,2,1,2,3,3]
        var dp = Array(repeating: 0, count: n + 1)
        dp[1] = 1
        // O(n * square root of n)
        for num in 2...n { //num=8
            var result = Int.max
            for perfectSquare in perfectSquares where num >= perfectSquare {
                result = min(result, 1 + dp[num - perfectSquare])
            }
            dp[num] = result
        }
        return dp[n]
    }
}

Solution().numSquares(12)
Solution().numSquares(13)
