import UIKit

public class EncodeDecodeStrings {
    private let separator: Character = "#"
    
    public func encode(strings: [String]) -> String {
        var result = ""
        for string in strings {
            let encode = String(separator) + String(string.count) + string
            result += encode
        }
        return result
    }

    public func decode(str: String) -> [String] {
        if str.count == 0 { return [] }

        var result = [String]()
        let chars = Array(str)
        var index = 0
        while index < str.count {
            if chars[index] == separator {
                let count = Int(String(chars[index + 1])) ?? 0
                let star = str.index(str.startIndex, offsetBy: index + 2)
                let end = str.index(str.startIndex, offsetBy: index + 1 + count)
                let string = String(str[star...end])
                result.append(string)
                index = index + 1 + count + 1
            }
        }

        return result
    }
}

let encode = EncodeDecodeStrings().encode(strings: ["lint","code","love","you"])
let decode = EncodeDecodeStrings().decode(str: encode)

let encode1 = EncodeDecodeStrings().encode(strings: ["we", "say", ":", "yes"])
let decode1 = EncodeDecodeStrings().decode(str: encode1)
